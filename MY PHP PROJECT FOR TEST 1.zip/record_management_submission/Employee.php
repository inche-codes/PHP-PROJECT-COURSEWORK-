<?php
require_once "Database.php";

class Employee {
    private $db;

    public function __construct() {
        $this->db = (new Database())->conn;
    }

    public function create($name, $email, $phone, $position, $salary) {
        $stmt = $this->db->prepare("INSERT INTO employees (name, email, phone, position, salary) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssd", $name, $email, $phone, $position, $salary);
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }

    public function read() {
        $result = $this->db->query("SELECT * FROM employees ORDER BY id DESC");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function update($id, $name, $email, $phone, $position, $salary) {
        $stmt = $this->db->prepare("UPDATE employees SET name=?, email=?, phone=?, position=?, salary=? WHERE id=?");
        $stmt->bind_param("ssssdi", $name, $email, $phone, $position, $salary, $id);
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM employees WHERE id=?");
        $stmt->bind_param("i", $id);
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }

    public function __destruct() {
        $this->db->close();
    }
}
?>
