<?php
require_once "Employee.php";
$emp = new Employee();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $employees = $emp->read();
    foreach ($employees as $e) {
        if ($e['id'] == $id) { $employee = $e; break; }
    }
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $emp->update($_POST['id'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['position'], $_POST['salary']);
    header("Location: read.php");
    exit;
}
?>

<h2>Update Employee</h2>
<form method="POST">
<input type="hidden" name="id" value="<?= $employee['id'] ?>">
Name: <input type="text" name="name" value="<?= $employee['name'] ?>"><br><br>
Email: <input type="email" name="email" value="<?= $employee['email'] ?>"><br><br>
Phone: <input type="text" name="phone" value="<?= $employee['phone'] ?>"><br><br>
Position: <input type="text" name="position" value="<?= $employee['position'] ?>"><br><br>
Salary: <input type="number" step="0.01" name="salary" value="<?= $employee['salary'] ?>"><br><br>
<button type="submit">Update</button>
</form>
<a href="read.php">Back</a>
