<?php
require_once "Employee.php";
$emp = new Employee();
$employees = $emp->read();
?>

<h2>Employee List</h2>
<a href="create.php">Add Employee</a>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Position</th><th>Salary</th><th>Actions</th></tr>
<?php foreach ($employees as $employee): ?>
<tr>
<td><?= $employee['id'] ?></td>
<td><?= $employee['name'] ?></td>
<td><?= $employee['email'] ?></td>
<td><?= $employee['phone'] ?></td>
<td><?= $employee['position'] ?></td>
<td><?= $employee['salary'] ?></td>
<td>
<a href="update.php?id=<?= $employee['id'] ?>">Edit</a> |
<a href="delete.php?id=<?= $employee['id'] ?>">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>
