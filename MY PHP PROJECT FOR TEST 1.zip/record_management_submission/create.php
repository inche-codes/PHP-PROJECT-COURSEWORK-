<?php
require_once "Employee.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $emp = new Employee();
    if ($emp->create($_POST['name'], $_POST['email'], $_POST['phone'], $_POST['position'], $_POST['salary'])) {
        header("Location: read.php");
        exit;
    }
}
?>

<h2>Add Employee</h2>
<form method="POST">
    Name: <input type="text" name="name" required><br><br>
    Email: <input type="email" name="email" required><br><br>
    Phone: <input type="text" name="phone"><br><br>
    Position: <input type="text" name="position"><br><br>
    Salary: <input type="number" step="0.01" name="salary"><br><br>
    <button type="submit">Add Employee</button>
</form>
<a href="read.php">View Employees</a>
