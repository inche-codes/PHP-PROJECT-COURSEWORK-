<?php
header("Location: read.php");
exit;
?>
