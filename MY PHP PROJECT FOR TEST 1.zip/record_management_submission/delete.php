<?php
require_once "Employee.php";
if (isset($_GET['id'])) {
    $emp = new Employee();
    $emp->delete($_GET['id']);
}
header("Location: read.php");
exit;
?>
